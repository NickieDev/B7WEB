## (Material apenas) RPG React

---

Este é um repositório contendo apenas o **material necessário** para criar o projeto [RPG React](https://github.com/suporteb7web/rpg-react).

---

Por:
[B7Web](https://b7web.com.br)